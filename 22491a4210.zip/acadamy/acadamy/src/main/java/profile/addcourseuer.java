package profile;

public class addcourseuer {
		private String cuourse_id,course_name,course_dure,course_timing;
		private Teacher teacher;
		public String getCuourse_id() {
			return cuourse_id;
		}
		public void setCuourse_id(String cuourse_id) {
			this.cuourse_id = cuourse_id;
		}
		public String getCourse_name() {
			return course_name;
		}
		public void setCourse_name(String course_name) {
			this.course_name = course_name;
		}
		public String getCourse_dure() {
			return course_dure;
		}
		public void setCourse_dure(String course_dure) {
			this.course_dure = course_dure;
		}
		public String getCourse_timing() {
			return course_timing;
		}
		public void setCourse_timing(String course_timing) {
			this.course_timing = course_timing;
		}
		public Teacher getTeacher() {
			return teacher;
		}
		public void setTeacher(Teacher teacher) {
			this.teacher = teacher;
		}
}
